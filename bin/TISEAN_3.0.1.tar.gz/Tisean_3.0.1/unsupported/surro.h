void perm(double *, long, long);
long pol_surr(long, double *, double *, double *, double *, long);
