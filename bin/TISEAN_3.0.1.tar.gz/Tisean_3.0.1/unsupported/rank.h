void minmax(long, double *, double *, double *);
void rank(long, double *, long *);
void rank2index(long, long *);
void sort(long, double *);
void indexx(long, double *, long *);
void rank2sort(long, double *, long *);
